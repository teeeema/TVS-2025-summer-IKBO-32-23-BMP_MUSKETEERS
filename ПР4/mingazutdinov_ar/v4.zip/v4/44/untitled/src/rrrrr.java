import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

class Car {
    private String model;
    private String license;
    private String color;
    private int year;
    private String ownerName;
    private String insuranceNumber;
    protected String engineType;
    private final int now = LocalDate.now().getYear();
    // ОШИБКА 1: Статическое поле, накапливающее ссылки на все созданные объекты
    // Приведет к утечке памяти, так как объекты никогда не будут собраны GC
    private static List<Car> allCars = new ArrayList<>();

    public Car() {
        this.model = "ERROR";
        this.license = "ERROR";
        this.color = "ERROR";
        this.year = 0;
        allCars.add(this); // Добавляем каждый созданный объект в список
    }

    public Car(String model, String license, String color, int year) {
        this.model = model;
        this.license = license;
        this.color = color;
        this.year = year;
        allCars.add(this); // Добавляем каждый созданный объект в список
    }

    public Car(String model, int year) {
        this.model = model;
        this.year = year;
        this.license = "ERROR";
        this.color = "ERROR";
        allCars.add(this); // Добавляем каждый созданный объект в список
    }

    public String toString() {
        // ОШИБКА 2: Возможное деление на ноль при определенных условиях
        // Проявится только при выполнении
        int riskyCalculation = 100 / (model.length() - 5); // Если model.length() == 5 - ArithmeticException
        return "Model: " + model + "\n" +
                "License plate: " + license + "\n" +
                "Color: " + color + "\n" +
                "Year: " + year + "\n" +
                "Owner: " + (ownerName != null ? ownerName : "none") + "\n" +
                "Insurance: " + (insuranceNumber != null ? insuranceNumber : "none") + "\n" +
                "Engine: " + (engineType != null ? engineType : "not specified") + "\n";
    }

    public int getAge() {
        // Имитация нагрузки
        int sum = 0;
        for (int i = 0; i < 1000; i++) {
            sum += i;
        }
        return now - year;
    }
}

class ElectricCar extends Car {
    private int batteryCapacity;
    private static byte[] largeMemoryChunk; // Большой кусок памяти

    public ElectricCar(String model, String license, String color, int year, int batteryCapacity) {
        super(model, license, color, year);
        this.batteryCapacity = batteryCapacity;
        this.engineType = "Electric motor";

        // ОШИБКА 3: Утечка памяти в статическом поле
        // Каждый ElectricCar выделяет большой массив, который никогда не освобождается
        largeMemoryChunk = new byte[1024 * 1024 * 10]; // 10 MB каждый раз
    }

    public int getBatteryCapacity() { return batteryCapacity; }
    public void setBatteryCapacity(int batteryCapacity) { this.batteryCapacity = batteryCapacity; }

    public String toString() {
        // Имитация нагрузки
        String result = super.toString(); // Может вызвать ArithmeticException из родительского класса
        for (int i = 0; i < 500; i++) {
            result.length(); // Просто вызов
        }
        return result + "Battery: " + batteryCapacity + " kWh\n";
    }
}

public class rrrrr {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("Программа запущена. PID: " + ProcessHandle.current().pid());
        System.out.println("Работает 60 секунд...");
        System.out.println("=== ПОДКЛЮЧАЙТЕ АНАЛИЗАТОР СЕЙЧАС ===");

        long startTime = System.currentTimeMillis();
        long duration = 60000; // 60 секунд

        // Создаем много объектов для анализа памяти
        int objectCount = 0;
        while (System.currentTimeMillis() - startTime < duration) {
            // Через каждые 10000 объектов создаем ElectricCar с утечкой памяти
            if (objectCount % 10000 == 0 && objectCount > 0) {
                try {
                    ElectricCar ev = new ElectricCar("TESLA_" + objectCount,
                            "E" + objectCount + "V",
                            "white",
                            2023,
                            75);
                    ev.getAge();
                    // Модель "TESLA_10000" имеет длину 11, но "TESLA_1000" имеет длину 10
                    // "TESLA_100000" уже имеет длину 12 - деление на ноль произойдет для некоторых значений
                } catch (Exception e) {
                    // Игнорируем исключение - плохая практика обработки ошибок
                    System.out.println("Ошибка при создании ElectricCar, но продолжаем работу...");
                }
            } else {
                // Создаем обычный Car
                // Модель "MAZDA_5" вызовет ArithmeticException в toString()
                Car car = new Car("MAZDA_" + objectCount, "A" + objectCount + "BC", "black", 2022);
                try {
                    car.getAge();
                    // Не вызываем toString() здесь, чтобы избежать немедленного исключения
                } catch (Exception e) {
                    // Игнорируем исключение - плохая практика
                }
            }

            if (objectCount % 1000 == 0) {
                long elapsed = System.currentTimeMillis() - startTime;
                System.out.println("Создано объектов: " + objectCount +
                        ", Прошло времени: " + (elapsed/1000) + " сек");

                // Принудительно вызываем сборку мусора, но она не поможет из-за утечек
                System.gc();
            }

            objectCount++;

            // Небольшая пауза каждые 100 объектов
            if (objectCount % 100 == 0) {
                Thread.sleep(10);
            }
        }

        System.out.println("=== ИТОГО ===");
        System.out.println("Создано объектов Car: " + objectCount);
        System.out.println("Завершено!");

        // Дополнительная пауза перед завершением
        Thread.sleep(5000);
    }
}