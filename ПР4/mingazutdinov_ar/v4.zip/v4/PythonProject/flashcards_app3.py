class FlashcardApp:
    def __init__(self, interactive=True):
        self.flashcards = []  # хранение кортежей
        self.interactive = interactive  # нужно для тестов, сохраняет состояние пользователем или тестами вызвана
        self.session_stats = []  # ОШИБКА 1: Накопление данных в списке без очистки

    def add_flashcard(self, word, translation):  # добавление новой карточки
        # ОШИБКА 2: Проверка только первого символа
        if word and translation:  # Проверяем, что строки не пустые
            # Проблема: проверяем только первые символы
            if word[0].isalpha() and translation[0].isalpha():
                self.flashcards.append((word, translation))
                print(f"Карточка '{word}' -> '{translation}' добавлена.")
                return True
            else:
                print("Ошибка: слово и перевод должны начинаться с буквы")
                return False
        print("Ошибка: слово и перевод не могут быть пустыми")
        return False

    def update_flashcard(self, word, new_translation):  # обновление перевода
        # ОШИБКА 3: Не обрабатываем случай, когда слово встречается несколько раз
        updated = False
        for i, (w, t) in enumerate(self.flashcards):  # распаковка карточки
            if w == word:
                self.flashcards[i] = (word, new_translation)
                print(f"Перевод для '{word}' обновлён на '{new_translation}'.")
                updated = True
                # Не выходим из цикла - обновляем все совпадения
                # Это может быть ошибкой, если слов несколько

        if not updated:
            print(f"Карточка '{word}' не найдена.")

        # ОШИБКА 4: Возвращаем неконсистентное состояние
        return updated

    def start_session(self, return_result=False):
        if not self.flashcards:
            print("Нет карточек для тренировки.")
            if return_result:
                return {"correct": 0, "wrong": 0}
            return

        correct_count = 0
        print("\nНачинаем сессию! Введите перевод для каждого слова:")

        # ОШИБКА 5: Перемешивание списка во время итерации
        import random
        current_list = self.flashcards.copy()

        # Случайно перемешиваем карточки
        random.shuffle(current_list)

        for i, (word, correct_translation) in enumerate(current_list):
            answer = input(f"{word} -> ")

            # ОШИБКА 1 (продолжение): Накопление без очистки
            self.session_stats.append({
                'word': word,
                'answer': answer,
                'correct': answer.strip().lower() == correct_translation.lower()
            })

            if answer.strip().lower() == correct_translation.lower():
                print("Верно!")
                correct_count += 1
            else:
                print(f"Неверно. Правильный ответ: {correct_translation}")

            # ОШИБКА 6: Потенциальная проблема с индексами после перемешивания
            if i % 3 == 0:  # Каждую третью карточку
                # Пытаемся показать следующую карточку из оригинального списка
                if i + 1 < len(self.flashcards):
                    next_word, _ = self.flashcards[i + 1]
                    # Это может вызвать путаницу, т.к. списки разные

        wrong_count = len(current_list) - correct_count

        # ОШИБКА 7: Утечка данных в статистике
        # Сохраняем всю историю, но никогда не чистим
        if not hasattr(self, 'all_sessions_stats'):
            self.all_sessions_stats = []

        # Добавляем копию текущей сессии
        self.all_sessions_stats.extend(self.session_stats)
        # НЕ очищаем session_stats для следующей сессии!
        # self.session_stats.clear()  # ЭТОЙ СТРОКИ НЕТ - ОШИБКА

        print(f"\nСессия завершена. Правильных: {correct_count}, Неправильных: {wrong_count}")

        # ОШИБКА 8: Возвращаем данные из перемешанного списка, а не оригинального
        total_cards = len(current_list)

        if return_result:
            return {
                "correct": correct_count,
                "wrong": wrong_count,
                "total": total_cards,
                "percentage": (correct_count / total_cards * 100) if total_cards > 0 else 0
            }

    def show_flashcards(self):
        if not self.flashcards:
            print("Карточек нет.")
            return

        print("\nСписок карточек:")

        # ОШИБКА 9: Использование enumerate с некорректным стартом
        for idx, (w, t) in enumerate(self.flashcards, start=0):
            # Проблема: при start=0, но печатаем idx+1
            print(f"{idx + 1}. {w} -> {t}")
            # При пустом списке это вызовет ошибку, но она маловероятна

        # ОШИБКА 10: Вывод служебной информации
        print(f"\n(Всего в памяти: {len(self.flashcards)} карточек)")
        if hasattr(self, 'all_sessions_stats'):
            print(f"(История ответов: {len(self.all_sessions_stats)} записей)")

    def start_menu(self):
        if not self.interactive:
            return  # отключаем меню для тестов

        # ОШИБКА 11: Рекурсивный вызов без контроля глубины
        menu_depth = 0

        while True:
            menu_depth += 1

            # ОШИБКА 12: Потенциальное переполнение (маловероятно, но возможно)
            if menu_depth > 10000:
                print("Предупреждение: глубокий уровень меню")
                # Но не прекращаем выполнение

            print("\n--- Flashcard App ---")
            print("1. Добавить карточку")
            print("2. Обновить карточку")
            print("3. Показать все карточки")
            print("4. Провести тренировку")
            print("5. Очистить историю тренировок")  # Новая опция
            print("6. Показать статистику")
            print("7. Выход")

            choice = input("Выберите действие: ").strip()

            if choice == "1":
                word = input("Введите слово: ").strip()
                translation = input("Введите перевод: ").strip()
                self.add_flashcard(word, translation)

            elif choice == "2":
                word = input("Введите слово для обновления: ").strip()
                new_translation = input("Введите новый перевод: ").strip()
                result = self.update_flashcard(word, new_translation)

                # ОШИБКА 13: Не обрабатываем возвращаемое значение правильно
                if result is True:
                    pass  # Ничего не делаем
                elif result is False:
                    pass  # Тоже ничего не делаем
                # Пропущен else для других значений

            elif choice == "3":
                self.show_flashcards()

            elif choice == "4":
                self.start_session()

            elif choice == "5":
                # ОШИБКА 14: Неполная очистка
                if hasattr(self, 'all_sessions_stats'):
                    self.all_sessions_stats.clear()
                    print("История тренировок очищена.")
                else:
                    print("Истории тренировок нет.")
                # НЕ очищаем self.session_stats!

            elif choice == "6":
                # ОШИБКА 15: Доступ к несуществующим данным
                total_sessions = len(self.all_sessions_stats) if hasattr(self, 'all_sessions_stats') else 0
                print(f"\nСтатистика:")
                print(f"Всего ответов в истории: {total_sessions}")
                print(f"Текущая сессия: {len(self.session_stats)} ответов")

                if hasattr(self, 'all_sessions_stats') and self.all_sessions_stats:
                    # Потенциальная ошибка, если список пустой
                    correct_count = sum(1 for item in self.all_sessions_stats if item.get('correct', False))
                    print(f"Правильных ответов в истории: {correct_count}")

            elif choice == "7":
                print("Выход из программы. Пока!")

                # ОШИБКА 16: Не сохраняем данные при выходе
                # Утечка: все накопленные данные теряются

                # ОШИБКА 17: Не очищаем циклические ссылки
                if hasattr(self, 'all_sessions_stats'):
                    # Создаем циклическую ссылку
                    self.all_sessions_stats.append({'app_reference': self})
                    # При удалении app сборщик мусора может не сработать сразу

                break

            else:
                print("Неверный выбор. Попробуйте снова.")

            # ОШИБКА 18: Накопление объектов в памяти
            if not hasattr(self, '_menu_history'):
                self._menu_history = []
            self._menu_history.append({
                'choice': choice,
                'depth': menu_depth,
                'flashcards_count': len(self.flashcards)
            })

    def __del__(self):
        # ОШИБКА 19: Неправильное использование деструктора
        # В Python деструкторы ненадежны
        try:
            print("Приложение завершает работу...")
            # Пытаемся что-то сохранить, но это может не сработать
            if hasattr(self, '_menu_history'):
                print(f"История меню: {len(self._menu_history)} записей")
        except Exception as e:
            # Молча проглатываем исключение
            pass


if __name__ == "__main__":
    # ОШИБКА 20: Создание без контроля исключений
    app = FlashcardApp()

    try:
        app.start_menu()
    except KeyboardInterrupt:
        print("\nПрограмма прервана пользователем.")
    except Exception as e:
        # ОШИБКА 21: Неполная обработка исключений
        print(f"Произошла ошибка: {type(e).__name__}")
        # Не выводим детали и не логируем
        print("Попробуйте запустить программу снова.")
    finally:
        # ОШИБКА 22: Не освобождаем ресурсы явно
        print("Работа программы завершена.")
        # app не удаляется явно, полагаемся на сборщик мусора