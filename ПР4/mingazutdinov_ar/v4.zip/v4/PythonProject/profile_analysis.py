import cProfile
import pstats
from flashcards_app import FlashcardApp


def profile_app_performance():
    """Профилируем производительность приложения"""
    app = FlashcardApp(interactive=False)

    # Тестовая функция для профилирования
    def test_operations():
        # Добавляем 100 карточек
        for i in range(100):
            app.add_flashcard(f"word{i}", f"translation{i}")

        # Обновляем 50 карточек
        for i in range(0, 100, 2):
            app.update_flashcard(f"word{i}", f"new_translation{i}")

        # Показываем карточки
        app.show_flashcards()

    # Запускаем профилировщик
    profiler = cProfile.Profile()
    profiler.enable()

    test_operations()

    profiler.disable()

    # Сохраняем результаты
    stats = pstats.Stats(profiler)
    stats.sort_stats('cumulative')  # сортируем по общему времени

    print("=== АНАЛИЗ ПРОИЗВОДИТЕЛЬНОСТИ (cProfile) ===")
    print("\n1. Самые затратные функции:")
    stats.print_stats(10)  # топ-10 функций

    print("\n2. Анализ функций FlashcardApp:")
    stats.print_stats('flashcards_app.py')


if __name__ == "__main__":
    profile_app_performance()