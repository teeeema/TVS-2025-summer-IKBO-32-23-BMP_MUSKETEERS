import cProfile
import pstats
import io
from flashcards_app3 import FlashcardApp
import builtins


def mock_input_sequence(sequence):
    """Мокаем ввод для тестирования"""
    inputs = iter(sequence)
    original_input = builtins.input

    def mock_input(prompt):
        try:
            response = next(inputs)
            print(prompt + str(response))  # Для отладки
            return response
        except StopIteration:
            return ""

    builtins.input = mock_input
    return original_input


def test_inefficient_search():
    """Тестируем неэффективный поиск (Ошибка 3)"""
    print("=== ТЕСТ НЕЭФФЕКТИВНОГО ПОИСКА ===")
    app = FlashcardApp(interactive=False)

    # Добавляем много карточек с одинаковыми словами
    for i in range(100):
        app.add_flashcard("duplicate_word", f"translation_{i}")

    # Тестируем поиск - должен найти ВСЕ 100 карточек
    app.update_flashcard("duplicate_word", "new_translation")

    # Проверяем, сколько карточек обновилось
    updated_count = sum(1 for w, t in app.flashcards if t == "new_translation")
    print(f"Обновлено карточек: {updated_count} из 100")
    print("⚠️ ОШИБКА: Обновляются ВСЕ совпадения, а не первое!")


def test_validation_error():
    """Тестируем некорректную валидацию (Ошибка 2)"""
    print("\n=== ТЕСТ НЕКОРРЕКТНОЙ ВАЛИДАЦИИ ===")
    app = FlashcardApp(interactive=False)

    test_cases = [
        ("hello", "world", True),  # Оба с букв
        ("123hello", "world", False),  # Первое с цифры
        ("hello", "123world", False),  # Второе с цифры
        (" hello", "world", False),  # Первое с пробела
        ("hello", "", False),  # Пустой перевод
        ("", "world", False),  # Пустое слово
    ]

    for word, trans, expected in test_cases:
        result = app.add_flashcard(word, trans)
        success = result is True
        print(f"'{word}' -> '{trans}': {'✓' if success == expected else '✗'} "
              f"(ожидалось: {expected}, получили: {success})")


def test_session_errors():
    """Тестируем ошибки в сессии"""
    print("\n=== ТЕСТ ОШИБОК СЕССИИ ===")
    app = FlashcardApp(interactive=False)

    # Добавляем тестовые карточки
    for i in range(5):
        app.add_flashcard(f"word{i}", f"trans{i}")

    # Имитируем ввод пользователя
    input_sequence = ["trans0", "wrong", "trans2", "trans3", "trans4"]
    original_input = mock_input_sequence(input_sequence)

    try:
        result = app.start_session(return_result=True)
        print(f"Результат сессии: {result}")

        # Проверяем накопление session_stats
        print(f"Записей в session_stats: {len(app.session_stats)}")

        # Еще одна сессия - session_stats должен расти
        mock_input_sequence(["trans0", "trans1", "trans2", "trans3", "trans4"])
        app.start_session(return_result=False)
        print(f"Записей в session_stats после 2й сессии: {len(app.session_stats)}")
        print("⚠️ ОШИБКА: session_stats не очищается между сессиями!")

    finally:
        builtins.input = original_input


def run_all_tests():
    """Запуск всех тестов с профилированием"""
    print("ЗАПУСК ТЕСТОВ С ПРОФИЛИРОВАНИЕМ...")

    # Создаем профилировщик
    profiler = cProfile.Profile()
    profiler.enable()

    # Запускаем тесты
    test_inefficient_search()
    test_validation_error()
    test_session_errors()

    profiler.disable()

    # Анализируем результаты
    print("\n" + "=" * 60)
    print("РЕЗУЛЬТАТЫ ПРОФИЛИРОВАНИЯ (cProfile):")
    print("=" * 60)

    stats = pstats.Stats(profiler)
    stats.strip_dirs().sort_stats('cumulative')

    print("\n--- Топ 15 функций по времени выполнения ---")
    stats.print_stats(15)

    print("\n--- Функции с наибольшим числом вызовов ---")
    stats.sort_stats('calls').print_stats(10)

    print("\n--- Анализ функций FlashcardApp ---")
    stats.sort_stats('time').print_stats('flashcards_app_with_errors')

    # Сохраняем в файл
    output = io.StringIO()
    stats.stream = output
    stats.print_stats()

    with open('performance_errors_report.txt', 'w') as f:
        f.write(output.getvalue())

    print("\nПолный отчет сохранен в 'performance_errors_report.txt'")


if __name__ == "__main__":
    run_all_tests()