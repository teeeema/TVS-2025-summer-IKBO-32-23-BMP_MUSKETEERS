from memory_profiler import profile
import builtins
import gc

# Импортируем класс из вашего файла
from flashcards_app3 import FlashcardApp


def mock_input_for_memory_test(answers):
    """Мокаем ввод для тестов памяти"""
    answers_iter = iter(answers)
    original_input = builtins.input

    def mock_input(prompt):
        return next(answers_iter)

    builtins.input = mock_input
    return original_input


@profile
def test_memory_leak_scenario():
    """Тестируем утечку памяти из-за накопления session_stats"""
    print("=== ТЕСТ УТЕЧКИ ПАМЯТИ ===")

    app = FlashcardApp(interactive=False)

    print("1. Начальное состояние")

    # Добавляем 20 карточек (уменьшил для скорости)
    for i in range(20):
        app.add_flashcard(f"word_{i}", f"translation_{i}")

    print("2. После добавления карточек")

    # Мокаем ввод для сессий
    answers = ["wrong"] * 20  # Все неправильные ответы
    original_input = mock_input_for_memory_test(answers)

    try:
        # Запускаем 3 сессии подряд
        for session in range(3):
            print(f"\n3. Перед сессией {session + 1}")

            # Меняем ответы для каждой сессии
            answers = [f"answer_{session}_{i}" for i in range(20)]
            mock_input_for_memory_test(answers)

            result = app.start_session(return_result=True)
            if result:
                print(f"   Сессия {session + 1}: {result.get('correct', 0)}/{result.get('total', 0)} правильных")

            # Проверяем рост session_stats
            print(f"   session_stats: {len(app.session_stats)} записей")

            if hasattr(app, 'all_sessions_stats'):
                print(f"   all_sessions_stats: {len(app.all_sessions_stats)} записей")

        print("\n4. После 3 сессий")
        print(f"   Итого в session_stats: {len(app.session_stats)} записей")
        if hasattr(app, 'all_sessions_stats'):
            print(f"   Итого в all_sessions_stats: {len(app.all_sessions_stats)} записей")

        # ОШИБКА: Должно быть 20, а не 60!
        expected = 20  # Только последняя сессия
        actual = len(app.session_stats)
        print(f"    УТЕЧКА: Ожидалось {expected}, получили {actual}")

    finally:
        builtins.input = original_input

    print("\n5. Попытка очистки через меню (опция 5)")
    # Вызываем очистку истории
    if hasattr(app, 'all_sessions_stats'):
        app.all_sessions_stats.clear()

    # Но session_stats все еще не очищен!
    print(f"   session_stats после 'очистки': {len(app.session_stats)} записей")

    return app


@profile
def test_circular_reference():
    """Тестируем циклические ссылки"""
    print("\n=== ТЕСТ ЦИКЛИЧЕСКИХ ССЫЛОК ===")

    apps = []

    for i in range(5):  # Уменьшил количество для скорости
        print(f"\nСоздание приложения {i + 1}")
        app = FlashcardApp(interactive=False)

        # Добавляем данные
        app.add_flashcard("test", "translation")

        # Запускаем сессию (создаем статистику)
        answers = ["test_answer"]
        original_input = mock_input_for_memory_test(answers)

        try:
            app.start_session(return_result=False)
        finally:
            builtins.input = original_input

        apps.append(app)

        # Принудительно запускаем сборку мусора
        gc.collect()

    print("\nУдаляем ссылки на приложения...")
    del apps

    print("Принудительный сбор мусора...")
    gc.collect()

    # Проверяем циклические ссылки
    print("\nПроверка циклических ссылок...")
    garbage = gc.collect()
    print(f"Собрано мусора: {garbage} объектов")


@profile
def test_menu_memory_growth():
    """Тестируем рост памяти в меню из-за _menu_history"""
    print("\n=== ТЕСТ РОСТА ПАМЯТИ В МЕНЮ ===")

    app = FlashcardApp(interactive=False)

    # Имитируем работу меню
    print("1. Имитация работы меню...")

    # Инициализируем _menu_history, если его нет
    if not hasattr(app, '_menu_history'):
        app._menu_history = []

    def simulate_menu_choice(choice):
        """Имитируем выбор в меню"""
        if choice == "1":
            app.add_flashcard("test_word", "test_translation")
        elif choice == "3":
            app.show_flashcards()
        elif choice == "5":
            if hasattr(app, 'all_sessions_stats'):
                app.all_sessions_stats.clear()

        # Записываем в историю (как в оригинальном коде)
        app._menu_history.append({
            'choice': choice,
            'depth': len(app._menu_history) + 1,
            'flashcards_count': len(app.flashcards)
        })

    # Симулируем 100 действий в меню (уменьшил для скорости)
    for i in range(100):
        simulate_menu_choice("1")  # Добавить карточку
        if i % 5 == 0:  # Каждую 5-ю итерацию
            simulate_menu_choice("3")  # Показать карточки
        if i % 20 == 0:  # Каждую 20-ю итерацию
            simulate_menu_choice("5")  # Очистить историю

    print("2. После 100 действий в меню")
    print(f"   Записей в _menu_history: {len(app._menu_history)}")
    print(f"   Размер flashcard: {len(app.flashcards)}")

    #  ОШИБКА: _menu_history растет без ограничений
    print("    ПРОБЛЕМА: _menu_history накапливает все действия!")


@profile
def test_validation_memory():
    """Тестируем память при некорректной валидации"""
    print("\n=== ТЕСТ ПАМЯТИ ПРИ ВАЛИДАЦИИ ===")

    app = FlashcardApp(interactive=False)

    print("1. Тестируем добавление карточек с разными данными")

    # Пробуем добавлять карточки с разными данными
    test_cases = [
        ("valid", "translation"),  # ОК
        ("123invalid", "translation"),  # Начинается с цифры
        ("", "translation"),  # Пустое слово
        ("word", ""),  # Пустой перевод
        (" word", "translation"),  # Пробел в начале
        ("word" * 100, "translation"),  # Длинное слово
    ]

    for word, translation in test_cases:
        result = app.add_flashcard(word, translation)
        print(f"   '{word[:20]}...' -> '{translation[:20]}...': {'✓' if result else '✗'}")

    print(f"\n2. Итоговое количество карточек: {len(app.flashcards)}")
    print("    ОШИБКА: Проверяется только первый символ!")


def run_memory_analysis():
    """Запуск всех тестов памяти"""
    print("ЗАПУСК АНАЛИЗА ПАМЯТИ С ОШИБКАМИ...")
    print("=" * 60)

    app = test_memory_leak_scenario()

    print("\n" + "=" * 60)
    test_validation_memory()

    print("\n" + "=" * 60)
    test_circular_reference()

    print("\n" + "=" * 60)
    test_menu_memory_growth()

    print("\n" + "=" * 60)
    print("ИТОГИ АНАЛИЗА ПАМЯТИ:")
    print("=" * 60)

    # Финальные замеры
    import psutil
    import os
    process = psutil.Process(os.getpid())
    memory_mb = process.memory_info().rss / 1024 / 1024

    print(f"\nФинальное использование памяти: {memory_mb:.2f} MB")

    # Анализ объектов в памяти
    print("\nОбъекты в памяти приложения:")
    print(f"  session_stats: {len(app.session_stats)} записей")

    if hasattr(app, 'all_sessions_stats'):
        print(f"  all_sessions_stats: {len(app.all_sessions_stats)} записей")

    if hasattr(app, '_menu_history'):
        print(f"  _menu_history: {len(app._menu_history)} записей")
    else:
        print("  _menu_history: атрибут не создан")

    print(f"  flashcards: {len(app.flashcards)} карточек")

    print("\n ВЫЯВЛЕННЫЕ ПРОБЛЕМЫ:")
    print("1. session_stats не очищается между сессиями")
    print("2. _menu_history растет без ограничений (если создан)")
    print("3. Циклические ссылки при выходе (деструктор)")
    print("4. Накопление данных без очистки")
    print("5. Некорректная валидация (только первый символ)")


if __name__ == "__main__":
    run_memory_analysis()