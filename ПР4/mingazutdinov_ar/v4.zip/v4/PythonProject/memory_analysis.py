from memory_profiler import profile
from flashcards_app import FlashcardApp


@profile  # Декоратор для анализа памяти
def analyze_memory_usage():
    """Анализируем использование памяти"""
    print("=== АНАЛИЗ ИСПОЛЬЗОВАНИЯ ПАМЯТИ ===")

    app = FlashcardApp(interactive=False)

    print("\n1. Память при пустом приложении")

    # Добавляем карточки и смотрим рост памяти
    print("\n2. Добавляем 500 карточек:")
    for i in range(500):
        app.add_flashcard(f"test_word_{i}", f"test_translation_{i}" * 5)  # длинный перевод

    print(f"   Всего карточек: {len(app.flashcards)}")

    # Тестируем обновление
    print("\n3. Обновляем 100 карточек:")
    for i in range(0, 500, 5):
        app.update_flashcard(f"test_word_{i}", f"UPDATED_{i}")

    # Тестируем показ
    print("\n4. Показываем карточки:")
    app.show_flashcards()

    print("\nАнализ завершен!")


if __name__ == "__main__":
    analyze_memory_usage()